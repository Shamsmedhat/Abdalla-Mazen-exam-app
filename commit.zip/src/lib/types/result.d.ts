
type WrongQuestion = {
  QID: string;
  Question: string;
  inCorrectAnswer: string;
  correctAnswer: string;
  answers: Record<string, string>; 
};


type CorrectQuestion = {
  QID: string;
  Question: string;
  correctAnswer: string;
  answers: Record<string, string>;
};

type ExamResultResponse = {
  message: string;
  correct: number;
  wrong: number;
  total: string; 
  WrongQuestions: WrongQuestion[];
  correctQuestions: CorrectQuestion[];
};