// import { getToken } from "next-auth/jwt";
// import { cookies } from "next/headers";

// export interface Subject {
//   id: number;
//   _id: string;
//   name: string;
//   icon: string;
//   createdAt: string;
// }

// export interface Metadata {
//   currentPage: number;
//   numberOfPages: number;
//   limit: number;
// }

// export interface SubjectsResponse {
//   message: string;
//   metadata: Metadata;
//   subjects: Subject[];
// }

// export async function getDiplomas(): Promise<SubjectsResponse> {
//   const token = await getToken({
//     req: {
//       cookies: Object.fromEntries(
//         cookies()
//           .getAll()
//           .map((c) => [c.name, c.value])
//       ),
//       // eslint-disable-next-line @typescript-eslint/no-explicit-any
//     } as any,
//     secret: process.env.NEXTAUTH_SECRET,
//   });
//   if (!token) {
//     throw new Error("Failed Token");
//   }
//   const response = await fetch(`${process.env.DIPLOMA_API_URL}`, {
//     method: "GET",
//     headers: {
//       "Content-Type": "application/json",
//       token: String(token?.accessToken),
//     },
//   });
//   if (!response.ok) throw new Error("Failed to fetch user");

//   return response.json();
// }
