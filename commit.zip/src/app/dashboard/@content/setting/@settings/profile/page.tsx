import React from "react";
import AccountForm from "./_components/account-setting";

export default function Profile() {
  return (
    <>
      {/* Account form component */}
      <AccountForm />
    </>
  );
}
