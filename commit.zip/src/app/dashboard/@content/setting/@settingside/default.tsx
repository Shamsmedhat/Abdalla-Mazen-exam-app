import React from 'react'

export default function PageDefault() {
  return <></>
}
