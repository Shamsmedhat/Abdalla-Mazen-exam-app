"use client";
import * as React from "react";
import { useEffect, useState } from "react";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Form, FormItem, FormControl } from "@/components/ui/form";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Controller, useForm } from "react-hook-form";

import getQuestions from "@/lib/apis/questions.api";
import TimerDonut from "../_components/timer-exam";
import { DynamicBreadcrumb } from "@/app/dashboard/_components/bread-crumb";
import { ChevronLeft, ChevronRight, CircleQuestionMark } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { submitAnswer } from "../_actions/submit-answer.action";
import Result from "./_component/result";
import Link from "next/link";

// Schema
const answerSchema = z.object({
  answers: z.record(z.string(), z.string().min(1, "Please choose answer")),
});

type AnswerValues = z.infer<typeof answerSchema>;
type Props = { params: { id: string } };

export default function ExamPage({ params }: Props) {
  // State
  const [questions, setQuestions] = useState<any[]>([]);
  const [current, setCurrent] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [timeLeft, setTimeLeft] = useState(0);
  const [totalSeconds, setTotalSeconds] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [result, setResult] = useState(false);

  // Form
  const form = useForm<AnswerValues>({
    resolver: zodResolver(answerSchema),
    defaultValues: { answers: {} },
  });
  const { errors } = form.formState;

  // Effects
  useEffect(() => {
    (async () => {
      try {
        const data = await getQuestions({ params: { id: params.id } });
        setQuestions(data?.questions || []);

        const duration = (data?.questions?.[0].exam?.duration || 20) * 60;
        setTotalSeconds(duration);

        const savedEndTime = localStorage.getItem("examEndTime");
        const idExam = localStorage.getItem("idExam");

        let endTime: number;
        if (savedEndTime && idExam === params.id) {
          endTime = parseInt(savedEndTime);
        } else {
          endTime = Date.now() + duration * 1000;
          localStorage.setItem("examEndTime", String(endTime));
          localStorage.setItem("idExam", params.id);
        }

        const remaining = Math.max(
          0,
          Math.floor((endTime - Date.now()) / 1000)
        );
        setTimeLeft(remaining);
      } catch (error) {
        console.error("Error loading questions:", error);
      }
    })();
  }, [params.id]);

  // Timer logic
  useEffect(() => {
    if (!totalSeconds || timeLeft <= 0) {
      if (timeLeft === 0 && totalSeconds > 0) {
        handleSubmitAll();
      }
      return;
    }
    // Variable
    const timer = setInterval(() => {
      setTimeLeft((prevTime) => {
        if (prevTime <= 1) {
          handleSubmitAll();
          return 0;
        }
        return prevTime - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [totalSeconds]);

  // Handle next question
  const handleNext = (values: AnswerValues) => {
    const q = questions[current];
    const currentAnswer = values.answers[q._id];

    const updatedAnswers = { ...answers, [q._id]: currentAnswer };
    setAnswers(updatedAnswers);
    setCurrent((c) => c + 1);

    const nextQuestion = questions[current + 1];
    if (nextQuestion) {
      form.reset({
        answers: { [nextQuestion._id]: updatedAnswers[nextQuestion._id] || "" },
      });
    }
  };

  // Handle previous question
  const handlePrevious = () => {
    const currentValues = form.getValues();
    const q = questions[current];
    if (currentValues.answers[q._id]) {
      setAnswers((prev) => ({
        ...prev,
        [q._id]: currentValues.answers[q._id],
      }));
    }

    setCurrent((c) => c - 1);

    const prevQuestion = questions[current - 1];
    if (prevQuestion) {
      form.reset({
        answers: { [prevQuestion._id]: answers[prevQuestion._id] || "" },
      });
    }
  };
  const [data, setData] = useState<ExamResultResponse | null>(null);
  // Final submit
  const handleSubmitAll = async () => {
    if (isSubmitting) return;
    setIsSubmitting(true);

    const payload = {
      answers: Object.entries(answers).map(([questionId, correct]) => ({
        questionId,
        correct,
      })),
      time: totalSeconds - timeLeft,
    };

    console.log("Payload to backend:", payload);
    const response = await submitAnswer(payload);
    console.log("response", response);
    setData(response);
    localStorage.removeItem("examEndTime");
    localStorage.removeItem("idExam");

    setResult(true);
  };

  // Load current question's answer when question changes
  useEffect(() => {
    if (questions.length > 0 && questions[current]) {
      const q = questions[current];
      form.reset({
        answers: { [q._id]: answers[q._id] || "" },
      });
    }
  }, [current, questions, answers, form]);

  // Loading state
  if (!questions.length) {
    return (
      <div className="flex justify-center items-center h-64">
        <p className="text-lg">Loading exam questions...</p>
      </div>
    );
  }

  const q = questions[current];
  if (!q) return <p>Question not found</p>;

  return (
    <div className="pt-0 flex flex-col min-h-screen">
      {/* Breadcrumb */}
      <div className="p-4">
        <DynamicBreadcrumb />
      </div>

      {/* Exam Header */}
      <div className="p-6 bg-gray-100">
        <div className="flex justify-between gap-2">
          <div className="border border-blue-600 flex items-center">
            <Link href={"/dashboard/exams"}>
            <ChevronLeft className="mx-2 text-blue-600" />
            </Link>
          </div>
          <div className="flex bg-blue-600 p-4 gap-4 text-white w-full">
            <CircleQuestionMark size={45} />
            {/* Headline */}
            <h1 className="text-3xl font-semibold">
              {q.exam?.title || "Questions"}
            </h1>
          </div>
        </div>
      </div>

      {/* Exam Body */}
      {!result ? (
        <div className="p-6 space-y-6 mx-6 bg-white flex-1">
          {/* Progress Bar */}
          <Progress
            value={((current + 1) / questions.length) * 100}
            className=" bg-blue-50 [&>div]:bg-blue-600"
          />

          {/* Form */}
          <Form {...form}>
            <form
              onSubmit={form.handleSubmit(
                current < questions.length - 1 ? handleNext : handleSubmitAll
              )}
              className="space-y-6 h-full flex flex-col"
            >
              {/* Question */}
              <section className="flex-1">
                <h2 className="text-blue-600 font-semibold text-2xl mb-6">
                  Question {current + 1} of {questions.length}: {q.question}
                </h2>

                {/* Answers */}
                <Controller
                  name={`answers.${q._id}`}
                  control={form.control}
                  defaultValue=""
                  render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <RadioGroup
                          value={field.value}
                          onValueChange={field.onChange}
                          className="space-y-3"
                        >
                          {q.answers?.map((ans: any) => (
                            <Label
                              htmlFor={`${q._id}-${ans.key}`}
                              key={ans.key}
                              className="cursor-pointer"
                            >
                              <div className="flex items-center space-x-3 bg-gray-50 p-4 rounded-lg hover:bg-gray-100 transition-colors">
                                <RadioGroupItem
                                  value={ans.key}
                                  id={`${q._id}-${ans.key}`}
                                  className="border-gray-400  data-[state=checked]:bg-blue-600 data-[state=checked]:text-white data-[state=checked]:border-blue-600 fill-none"
                                />
                                <span className="text-sm font-medium">
                                  {ans.answer}
                                </span>
                              </div>
                            </Label>
                          ))}
                        </RadioGroup>
                      </FormControl>

                      {/* Error */}
                      {errors.answers?.[q._id] && (
                        <Alert
                          variant="destructive"
                          className="text-center mb-4"
                        >
                          <AlertDescription>
                            Please choose the correct answer
                          </AlertDescription>
                        </Alert>
                      )}
                    </FormItem>
                  )}
                />
              </section>

              {/* Navigation Buttons */}
              <div className="flex justify-between items-center pt-6 ">
                {/* Previous */}
                <Button
                  type="button"
                  disabled={current === 0}
                  onClick={handlePrevious}
                  className="flex items-center gap-2 px-6 w-full py-3.5 rounded-none bg-gray-200 text-gray-400  font-medium  text-sm hover:bg-gray-300 hover:text-gray-500"
                >
                  <ChevronLeft size={16} />
                  Previous
                </Button>

                {/* Timer */}
                <div className="flex items-center gap-4">
                  <TimerDonut totalSeconds={totalSeconds} timeLeft={timeLeft} />
                </div>

                {/* Next | Submit buttton  */}
                {current < questions.length - 1 ? (
                  <Button
                    type="submit"
                    className="flex items-center py-3.5 gap-2 px-6 w-full rounded-none bg-blue-600 text-white  font-medium  text-sm hover:bg-blue-700 "
                  >
                    Next
                    <ChevronRight size={16} />
                  </Button>
                ) : (
                  <Button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-6  w-full py-3.5 rounded-none bg-blue-600 text-white  font-medium  text-sm hover:bg-blue-700"
                  >
                    {isSubmitting ? "Submitting..." : "Submit Exam"}
                  </Button>
                )}
              </div>
            </form>
          </Form>
        </div>
      ) : (
        // Result component
        <Result data={data} />
      )}
    </div>
  );
}
